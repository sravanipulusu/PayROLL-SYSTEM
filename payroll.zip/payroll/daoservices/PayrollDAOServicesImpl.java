package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl {

	private static Associate[] associateList = new Associate[10];
	private static int ASSOCIATE_ID_COUNTER = 111;
	private static int ASSOCIATE_IDX_COUNTER=0;


	public int insertAssociate(Associate associate) {
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateId();

	}
	public boolean updateAssociate(Associate associate) {
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null && associate.getAssociateId() == associateList[i].getAssociateId())
				associateList[i]=associate;

		}
		return true;
	}
	public boolean deleteAssociate(int asscociateId) {
		for(int i=0;i<associateList.length;i++){
			if(asscociateId == associateList[i].getAssociateId()){
			associateList[i]=null;	 
		return true;
			}
	}
		return false;
	}
	public Associate getAssociate(int associateId) {
		for(int i=0;i<associateList.length;i++){

			if(associateList[i].getAssociateId() == associateId)

			return associateList[i];
		}
	
		return null;
	}
	public Associate[] getAssociates() {
		return associateList;
	}	
}


