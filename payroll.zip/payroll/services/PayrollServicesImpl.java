package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
public class PayrollServicesImpl {
	private float annualTax;
	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl() {
		daoServices = new PayrollDAOServicesImpl();
	}


	public int acceptAssociateDetails(int yearlyInvestmentUnder80C,String firstName,String lastName,String department,
			String designation,String pancard, String emailId, int accountNumber,
			String bankName , String ifscCode, int basicSalary, int epf,int companyPf) {

		return daoServices.insertAssociate( (new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new salary(basicSalary, epf, companyPf))));
	}
	
	public float calculateNetSalary(int associateId) {
		if(getAssociateDetails(associateId)!=null) {
			Associate associate=getAssociateDetails(associateId);
			associate.getSalary1().setPersonalAllowance(0.3f*associate.getSalary1().getBasicSalary());
			associate.getSalary1().setConveyenceAllowance(0.2f*associate.getSalary1().getBasicSalary());
			associate.getSalary1().setOtherAllowance(0.1f*associate.getSalary1().getBasicSalary());
			associate.getSalary1().setHra(0.25f*associate.getSalary1().getBasicSalary());
			associate.getSalary1().setGratuity(0.05f*associate.getSalary1().getBasicSalary());
			associate.getSalary1().setGrossSalary(associate.getSalary1().getBasicSalary()+associate.getSalary1().getCompanyPf()+associate.getSalary1().getConveyenceAllowance()+associate.getSalary1().getPersonalAllowance()+associate.getSalary1().getOtherAllowance()+associate.getSalary1().getHra());
			float annualSalary=12*associate.getSalary1().getGrossSalary();
			if((associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary1().getCompanyPf())+(12*associate.getSalary1().getEpf())<=150000)) {
				if(annualSalary>=1000000) {
					annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary1().getCompanyPf())-(12*associate.getSalary1().getEpf()));
				}
				else if(annualSalary>=500000&&annualSalary<100000) 
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*(150000-(associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary1().getEpf()+12*associate.getSalary1().getCompanyPf())))));
				else if(annualSalary<500000 && annualSalary>=250000)
					if(annualSalary-250000>(associate.getYearlyInvestmentUnder80C()+associate.getSalary1().getCompanyPf()+associate.getSalary1().getEpf()))
						annualTax=0.1f*(annualSalary-250000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary1().getEpf()-12*associate.getSalary1().getCompanyPf()));
					else 
						annualTax=0;
				else if(annualSalary<250000)
					annualTax=0;
			}
			else {
				if(annualSalary>=1000000) 
					annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
				else if(annualSalary>=500000&&annualSalary<1000000)
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
				else if(annualSalary<500000 && annualSalary>=250000)
					annualTax=(0.1f*(100000));
				else
					annualTax=0;
			}
			associate.getSalary1().setMonthlyTax(annualTax/12);
			associate.getSalary1().setNetSalary(associate.getSalary1().getGrossSalary()-associate.getSalary1().getMonthlyTax()-associate.getSalary1().getCompanyPf()-associate.getSalary1().getEpf());
	return associate.getSalary1().getNetSalary();
		}
	return 0;
}
			public Associate getAssociateDetails(int associateId){
					return daoServices.getAssociate(associateId);	
			}
			public Associate[] getAssociateDetails() {
					return daoServices.getAssociates();
			}
}
