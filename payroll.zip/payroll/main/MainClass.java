package com.cg.payroll.main;

import com.cg.payroll.beans.*;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		PayrollServicesImpl payrollservices = new PayrollServicesImpl();
		int i=payrollservices.acceptAssociateDetails(150000, "sravani", "pulusu", "java", "btech", "sd4545", "sdsd@.com", 99999, "hdfc", "sdsds", 30000, 1000, 1000);

	System.out.println(i);
	System.out.println(payrollservices.calculateNetSalary(i));
	Associate a1=payrollservices.getAssociateDetails(i);
	System.out.println(a1.getSalary1().getGrossSalary() + "\n" +a1.getSalary1().getNetSalary());
	System.out.println(a1.getSalary1().getMonthlyTax());
	}

}